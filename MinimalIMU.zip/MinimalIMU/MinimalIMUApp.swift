import SwiftUI

@main
struct MinimalIMUApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
